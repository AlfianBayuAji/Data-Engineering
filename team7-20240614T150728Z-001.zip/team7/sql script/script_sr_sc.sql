CREATE TABLE studentresult (
    id_student SERIAL PRIMARY KEY,
    id_assessment INT,
    code_module VARCHAR(10),
    code_presentation VARCHAR(10),
    date_submitted INT,
    highest_education VARCHAR(100),
    gender VARCHAR(3),
    region VARCHAR(100),
    disability BOOLEAN,
    studied_credits INT,
    score INT,
    final_result VARCHAR(50)
);

select * from studentresult;

CREATE TABLE student_clicks (
    id_student INT,
    id_site INT,
    sum_click INT,
    code_module VARCHAR(10),
    code_presentation VARCHAR(10),
    date_registration INT,
    date_unregistration INT
);

select * from student_clicks;



