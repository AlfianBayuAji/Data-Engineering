CREATE TABLE olap (
    id_student SERIAL PRIMARY KEY,
    id_assessment INT,
    code_module VARCHAR(10),
    code_presentation VARCHAR(10),
    date_submitted INT,
    highest_education VARCHAR(100),
    gender VARCHAR(3),
    region VARCHAR(100),
    disability BOOLEAN,
    studied_credits INT,
    score INT,
    final_result VARCHAR(50),
    id_site BOOLEAN,
    sum_click BOOLEAN,
    date_registration BOOLEAN,
    date_unregistration BOOLEAN
    );

   \copy olap FROM '/home/armita/dummy_data/olap_transformasi.csv' DELIMITER ',' CSV HEADER;
  
  COPY olap FROM '/home/armita/dummy_data/olap_transformasi.csv' WITH (FORMAT csv, HEADER true, DELIMITER ',');
 
select * from olap;

select * from olap limit 1500;

CREATE TABLE olaplimit (
    id_student SERIAL PRIMARY KEY,
    id_assessment INT,
    code_module VARCHAR(10),
    code_presentation VARCHAR(10),
    date_submitted INT,
    highest_education VARCHAR(100),
    gender VARCHAR(3),
    region VARCHAR(100),
    disability BOOLEAN,
    studied_credits INT,
    score INT,
    final_result VARCHAR(50),
    id_site BOOLEAN,
    sum_click BOOLEAN,
    date_registration BOOLEAN,
    date_unregistration BOOLEAN
    );
   
   select * from olaplimit;


