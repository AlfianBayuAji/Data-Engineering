from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# initialization Spark Builder
spark = SparkSession.builder.appName("OLAPConversion").getOrCreate()

# Read CSV file from Hadoop dfs
student_result_df = spark.read.csv("/home/armita/de/studentresult.csv", header=True, inferSchema=True)
student_clicks_df = spark.read.csv("/home/armita/de/student_clicks.csv", header=True, inferSchema=True)

# Delete columns that are not needed
student_clicks_df = student_clicks_df.drop("id_student", "code_module", "c_presentation")

# Retrieve the DataFrame schema after column deletion
student_clicks_df.printSchema()
student_result_df.printSchema()

student_clicks_df.show()
student_result_df.show()

# Joining df & sr
olap = student_result_df.join(student_clicks_df, student_result_df.id_stud==student_clicks_df.id_site, "left")
olap.show()

# Create temporary views for SQL queries
olap.createOrReplaceTempView("olaplimit")
olap = spark.sql("select * from olaplimit limit 1500")
olap.show()

# Save output OLAP to Hadoop dfs
olap.write.option("header", "true").csv('/home/armita/de/olaplimit.csv')
spark.stop()