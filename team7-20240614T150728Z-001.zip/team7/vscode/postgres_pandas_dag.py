from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime
import pandas as pd

def fetch_data_from_postgres():
    hook = PostgresHook(postgres_conn_id='dataengineerconn')
    conn = hook.get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM olapnew")
    rows = cursor.fetchall()
    df = pd.DataFrame(rows, columns=[desc[0] for desc in cursor.description])
    # Proses DataFrame dengan Pandas
    print(df)

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
}

with DAG('postgres_pandas_dag',
         default_args=default_args,
         schedule_interval='@daily',
         catchup=False) as dag:

    create_table = PostgresOperator(
        task_id='create_table',
        postgres_conn_id='dataengineerconn',
        sql="""
        CREATE TABLE IF NOT EXISTS olap (
            id SERIAL PRIMARY KEY,
            name VARCHAR(50),
            age INT
        );
        """
    )

    fetch_data = PythonOperator(
        task_id='fetch_data',
        python_callable=fetch_data_from_postgres
    )

    create_table >> fetch_data