from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import pandas as pd

# Define default arguments
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
}

# Define the DAG
dag = DAG(
    'process_csv_dag',
    default_args=default_args,
    description='A DAG to process CSV file',
    schedule_interval='@daily',
    start_date=datetime(2023, 6, 1),
    catchup=False,
)

# Define the path to the CSV file
csv_file_path = '/home/armita/assignment/olaplimit.csv'

# Define the function to read and process CSV
def read_and_process_csv():
    df = pd.read_csv(csv_file_path)
    # Perform any data processing here
    print(df.head(10))  # Example: Print first 10 rows
    # You can add more data processing logic here

# Define the PythonOperator to read and process CSV
read_csv_task = PythonOperator(
    task_id='read_csv_task',
    python_callable=read_and_process_csv,
    dag=dag,
)

# Set task dependencies
read_csv_task
